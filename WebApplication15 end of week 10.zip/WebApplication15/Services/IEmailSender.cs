﻿namespace WebApplication15.Services
{
    public interface IEmailSender
    {
    }
}
